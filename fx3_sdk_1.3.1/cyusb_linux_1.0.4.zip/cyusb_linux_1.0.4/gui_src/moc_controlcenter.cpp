/****************************************************************************
** Meta object code from reading C++ file 'controlcenter.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../include/controlcenter.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controlcenter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_ControlCenter[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      54,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      15,   14,   14,   14, 0x0a,
      40,   14,   14,   14, 0x0a,
      65,   14,   14,   14, 0x0a,
      86,   14,   14,   14, 0x0a,
     115,  113,   14,   14, 0x0a,
     158,   14,   14,   14, 0x0a,
     180,   14,   14,   14, 0x0a,
     190,   14,   14,   14, 0x0a,
     198,   14,   14,   14, 0x08,
     232,  227,   14,   14, 0x08,
     276,   14,   14,   14, 0x08,
     294,   14,   14,   14, 0x08,
     319,   14,   14,   14, 0x08,
     342,   14,   14,   14, 0x08,
     363,   14,   14,   14, 0x08,
     386,   14,   14,   14, 0x08,
     409,   14,   14,   14, 0x08,
     431,   14,   14,   14, 0x08,
     454,   14,   14,   14, 0x08,
     477,   14,   14,   14, 0x08,
     499,   14,   14,   14, 0x08,
     521,   14,   14,   14, 0x08,
     546,   14,   14,   14, 0x08,
     569,   14,   14,   14, 0x08,
     593,   14,   14,   14, 0x08,
     614,   14,   14,   14, 0x08,
     634,   14,   14,   14, 0x08,
     659,   14,   14,   14, 0x08,
     682,   14,   14,   14, 0x08,
     702,   14,   14,   14, 0x08,
     730,   14,   14,   14, 0x08,
     760,   14,   14,   14, 0x08,
     791,   14,   14,   14, 0x08,
     816,   14,   14,   14, 0x08,
     839,   14,   14,   14, 0x08,
     862,   14,   14,   14, 0x08,
     890,   14,   14,   14, 0x08,
     920,   14,   14,   14, 0x08,
     951,   14,   14,   14, 0x08,
     974,   14,   14,   14, 0x08,
    1000,   14,   14,   14, 0x08,
    1024,   14,   14,   14, 0x08,
    1045,   14,   14,   14, 0x08,
    1067,   14,   14,   14, 0x08,
    1089,   14,   14,   14, 0x08,
    1113,   14,   14,   14, 0x08,
    1136,   14,   14,   14, 0x08,
    1167,   14,   14,   14, 0x08,
    1197,   14,   14,   14, 0x08,
    1220,   14,   14,   14, 0x08,
    1241,   14,   14,   14, 0x08,
    1265,   14,   14,   14, 0x08,
    1290,   14,   14,   14, 0x08,
    1321,   14,   14,   14, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_ControlCenter[] = {
    "ControlCenter\0\0on_pb_setIFace_clicked()\0"
    "on_pb_setAltIf_clicked()\0on_pb6_rcv_clicked()\0"
    "pb6_send_nofile_selected()\0,\0"
    "pb6_send_file_selected(unsigned char*,int)\0"
    "on_pb7_send_clicked()\0appExit()\0about()\0"
    "on_pb_kerneldetach_clicked()\0item\0"
    "on_listWidget_itemClicked(QListWidgetItem*)\0"
    "sigusr1_handler()\0on_pb1_selfile_clicked()\0"
    "on_pb1_start_clicked()\0on_rb1_ram_clicked()\0"
    "on_rb1_small_clicked()\0on_rb1_large_clicked()\0"
    "on_pb_reset_clicked()\0on_rb3_ramdl_clicked()\0"
    "on_rb3_ramup_clicked()\0on_rb3_eedl_clicked()\0"
    "on_rb3_eeup_clicked()\0on_rb3_getchip_clicked()\0"
    "on_rb3_renum_clicked()\0on_rb3_custom_clicked()\0"
    "on_rb3_out_clicked()\0on_rb3_in_clicked()\0"
    "on_pb3_selfile_clicked()\0"
    "on_pb_execvc_clicked()\0on_pb3_dl_clicked()\0"
    "on_le3_out_hex_textEdited()\0"
    "on_le3_out_ascii_textEdited()\0"
    "on_le3_out_ascii_textChanged()\0"
    "on_pb4_selfile_clicked()\0"
    "on_pb4_start_clicked()\0on_pb4_clear_clicked()\0"
    "on_le6_out_hex_textEdited()\0"
    "on_le6_out_ascii_textEdited()\0"
    "on_le6_out_ascii_textChanged()\0"
    "on_pb6_clear_clicked()\0on_rb6_constant_clicked()\0"
    "on_rb6_random_clicked()\0on_rb6_inc_clicked()\0"
    "on_pb6_send_clicked()\0on_cb6_loop_clicked()\0"
    "on_pb6_selout_clicked()\0on_pb6_selin_clicked()\0"
    "on_pb6_clearhalt_out_clicked()\0"
    "on_pb6_clearhalt_in_clicked()\0"
    "on_pb7_clear_clicked()\0on_pb7_rcv_clicked()\0"
    "on_rb7_enable_clicked()\0"
    "on_rb7_disable_clicked()\0"
    "on_pb7_clearhalt_out_clicked()\0"
    "on_pb7_clearhalt_in_clicked()\0"
};

void ControlCenter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ControlCenter *_t = static_cast<ControlCenter *>(_o);
        switch (_id) {
        case 0: _t->on_pb_setIFace_clicked(); break;
        case 1: _t->on_pb_setAltIf_clicked(); break;
        case 2: _t->on_pb6_rcv_clicked(); break;
        case 3: _t->pb6_send_nofile_selected(); break;
        case 4: _t->pb6_send_file_selected((*reinterpret_cast< unsigned char*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 5: _t->on_pb7_send_clicked(); break;
        case 6: _t->appExit(); break;
        case 7: _t->about(); break;
        case 8: _t->on_pb_kerneldetach_clicked(); break;
        case 9: _t->on_listWidget_itemClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 10: _t->sigusr1_handler(); break;
        case 11: _t->on_pb1_selfile_clicked(); break;
        case 12: _t->on_pb1_start_clicked(); break;
        case 13: _t->on_rb1_ram_clicked(); break;
        case 14: _t->on_rb1_small_clicked(); break;
        case 15: _t->on_rb1_large_clicked(); break;
        case 16: _t->on_pb_reset_clicked(); break;
        case 17: _t->on_rb3_ramdl_clicked(); break;
        case 18: _t->on_rb3_ramup_clicked(); break;
        case 19: _t->on_rb3_eedl_clicked(); break;
        case 20: _t->on_rb3_eeup_clicked(); break;
        case 21: _t->on_rb3_getchip_clicked(); break;
        case 22: _t->on_rb3_renum_clicked(); break;
        case 23: _t->on_rb3_custom_clicked(); break;
        case 24: _t->on_rb3_out_clicked(); break;
        case 25: _t->on_rb3_in_clicked(); break;
        case 26: _t->on_pb3_selfile_clicked(); break;
        case 27: _t->on_pb_execvc_clicked(); break;
        case 28: _t->on_pb3_dl_clicked(); break;
        case 29: _t->on_le3_out_hex_textEdited(); break;
        case 30: _t->on_le3_out_ascii_textEdited(); break;
        case 31: _t->on_le3_out_ascii_textChanged(); break;
        case 32: _t->on_pb4_selfile_clicked(); break;
        case 33: _t->on_pb4_start_clicked(); break;
        case 34: _t->on_pb4_clear_clicked(); break;
        case 35: _t->on_le6_out_hex_textEdited(); break;
        case 36: _t->on_le6_out_ascii_textEdited(); break;
        case 37: _t->on_le6_out_ascii_textChanged(); break;
        case 38: _t->on_pb6_clear_clicked(); break;
        case 39: _t->on_rb6_constant_clicked(); break;
        case 40: _t->on_rb6_random_clicked(); break;
        case 41: _t->on_rb6_inc_clicked(); break;
        case 42: _t->on_pb6_send_clicked(); break;
        case 43: _t->on_cb6_loop_clicked(); break;
        case 44: _t->on_pb6_selout_clicked(); break;
        case 45: _t->on_pb6_selin_clicked(); break;
        case 46: _t->on_pb6_clearhalt_out_clicked(); break;
        case 47: _t->on_pb6_clearhalt_in_clicked(); break;
        case 48: _t->on_pb7_clear_clicked(); break;
        case 49: _t->on_pb7_rcv_clicked(); break;
        case 50: _t->on_rb7_enable_clicked(); break;
        case 51: _t->on_rb7_disable_clicked(); break;
        case 52: _t->on_pb7_clearhalt_out_clicked(); break;
        case 53: _t->on_pb7_clearhalt_in_clicked(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData ControlCenter::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject ControlCenter::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_ControlCenter,
      qt_meta_data_ControlCenter, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &ControlCenter::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *ControlCenter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *ControlCenter::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_ControlCenter))
        return static_cast<void*>(const_cast< ControlCenter*>(this));
    if (!strcmp(_clname, "Ui::ControlCenter"))
        return static_cast< Ui::ControlCenter*>(const_cast< ControlCenter*>(this));
    return QWidget::qt_metacast(_clname);
}

int ControlCenter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 54)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 54;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
