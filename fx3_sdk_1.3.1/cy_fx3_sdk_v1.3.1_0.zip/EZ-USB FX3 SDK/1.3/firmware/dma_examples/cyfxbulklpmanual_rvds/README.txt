This is a directory for a sample RVDS project.
The example Bulk Loop Manual is used here.

Run copy_files.bat to copy the required source files for this project.
Then open the project in RVDS and build/debug.

Run remove_files.bat to remove all the copied and built files.