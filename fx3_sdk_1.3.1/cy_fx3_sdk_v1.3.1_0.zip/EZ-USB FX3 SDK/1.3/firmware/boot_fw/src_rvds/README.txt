The boot firmware can be built by both eclipse and RVDS.
As both RVDS and Eclipse use the same name for the project files, this 
directory stores the RVDS project files for the boot firmware.

Run copy_files.bat to copy the source files from the src directory.
Then open the project in RVDS and build/debug.

Run remove_files.bat to remove all the copied files.
